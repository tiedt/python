"""
Projeto.

Gera atividade com ritmo humano alternando entre VS Code, PowerShell e WSL,
dentro do horário configurado. Pausa quando você mexe na máquina ou deixa o
Chrome em primeiro plano, e encerra quando o arquivo de parada existir.

Uso:  python projeto.py [caminho/config.json]
Parar: Ctrl+C no terminal, ou criar o arquivo PARAR.txt na pasta.
"""

import ctypes
import json
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, time as dtime
from pathlib import Path

from pynput import keyboard, mouse
from pynput.keyboard import Controller as KbController, Key
from pynput.mouse import Controller as MouseController

WIN = sys.platform == "win32"
if WIN:
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

BASE = Path(__file__).resolve().parent
CREATE_NO_WINDOW = 0x08000000


# ---------------------------------------------------------------- utilidades

def log(msg):
    print(f"[{datetime.now():%H:%M:%S}] {msg}", flush=True)


def parse_hora(txt):
    h, m = txt.split(":")
    return dtime(int(h), int(m))


def manter_tela_acordada(ativar):
    if not WIN:
        return
    ES_CONTINUOUS, ES_SYSTEM, ES_DISPLAY = 0x80000000, 0x1, 0x2
    flags = ES_CONTINUOUS | (ES_SYSTEM | ES_DISPLAY if ativar else 0)
    kernel32.SetThreadExecutionState(flags)


def tamanho_tela():
    if WIN:
        return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    return 1920, 1080


# --------------------------------------------------------- janelas (Windows)

def titulo_janela(hwnd):
    tam = user32.GetWindowTextLengthW(hwnd) + 1
    buf = ctypes.create_unicode_buffer(tam)
    user32.GetWindowTextW(hwnd, buf, tam)
    return buf.value


def janela_ativa():
    return user32.GetForegroundWindow() if WIN else 0


def titulo_ativo():
    return titulo_janela(janela_ativa()) if WIN else ""


def listar_janelas():
    """(hwnd, pid, titulo) de todas as janelas visíveis com título."""
    res = []
    if not WIN:
        return res
    proto = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            t = titulo_janela(hwnd)
            if t:
                res.append((hwnd, pid.value, t))
        return True

    user32.EnumWindows(proto(cb), 0)
    return res


def janela_por_pid(pid):
    for hwnd, p, _ in listar_janelas():
        if p == pid:
            return hwnd
    return None


def janela_por_titulo(*trechos):
    for hwnd, _, t in listar_janelas():
        if all(x.lower() in t.lower() for x in trechos):
            return hwnd
    return None


def janela_existe(hwnd):
    return bool(hwnd) and WIN and user32.IsWindow(hwnd)


def focar(hwnd, kb):
    """Traz a janela para frente, contornando a trava de foco do Windows."""
    SW_RESTORE = 9
    user32.ShowWindow(hwnd, SW_RESTORE)
    if user32.GetForegroundWindow() == hwnd:
        return True
    fg = user32.GetForegroundWindow()
    fg_thread = user32.GetWindowThreadProcessId(fg, None)
    cur = kernel32.GetCurrentThreadId()
    user32.AttachThreadInput(cur, fg_thread, True)
    user32.BringWindowToTop(hwnd)
    user32.SetForegroundWindow(hwnd)
    user32.AttachThreadInput(cur, fg_thread, False)
    time.sleep(0.4)
    if user32.GetForegroundWindow() == hwnd:
        return True
    kb.press(Key.shift); kb.release(Key.shift)  # toque inofensivo libera a trava
    user32.SetForegroundWindow(hwnd)
    time.sleep(0.4)
    return user32.GetForegroundWindow() == hwnd


def exe_da_janela(hwnd):
    """Nome do executável (minúsculas) dono da janela, ou ''."""
    if not WIN or not hwnd:
        return ""
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    h = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        tam = wintypes.DWORD(1024)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(tam)):
            return os.path.basename(buf.value).lower()
        return ""
    finally:
        kernel32.CloseHandle(h)


# ------------------------------------------------------- detector de usuário

class DetectorUsuario:
    """Observa entrada real. Eventos que o próprio simulador injeta são ignorados."""

    def __init__(self):
        self.ultima_atividade_real = time.time()
        self._lock = threading.Lock()
        mouse.Listener(on_move=self._evento, on_click=self._evento,
                       on_scroll=self._evento, daemon=True).start()
        keyboard.Listener(on_press=self._evento, daemon=True).start()

    def _evento(self, *args):
        # pynput >= 1.8 passa "injected" como último argumento. Eventos
        # gerados por software (os nossos) têm injected=True; qualquer
        # outro é do usuário e conta na hora, mesmo no meio da digitação.
        if args and isinstance(args[-1], bool) and args[-1]:
            return
        with self._lock:
            self.ultima_atividade_real = time.time()

    def segundos_desde_usuario(self):
        return time.time() - self.ultima_atividade_real


# ------------------------------------------------------- geradores de conteúdo

NOMES = ["api-pedidos", "worker-notificacoes", "gateway", "auth-service",
         "relatorios", "sync-estoque", "cache-sessao", "importador-nf"]
AMBIENTES = ["dev", "hml", "prod"]
TAREFAS = ["revisar o relatório antes da reunião", "verificar o status do chamado",
           "responder o e-mail do fornecedor", "atualizar a planilha de custos",
           "anotar os pontos da daily", "conferir os números do fechamento",
           "validar o deploy de homologação", "ajustar timeout do serviço"]


def _ver():
    return f"1.{random.randint(0, 9)}.{random.randint(0, 20)}"


def gerar_yaml(nome):
    env = random.choice(AMBIENTES)
    inicio = [f"# configuração do {nome}", "app:", f"  name: {nome}",
              f"  version: {_ver()}", f"  env: {env}", f"  port: {random.randint(3000, 9000)}"]
    resto = ["database:", f"  host: db-{env}.interno", "  port: 5432",
             f"  pool_size: {random.randint(5, 30)}", "logging:",
             f"  level: {random.choice(['info', 'debug', 'warn'])}", "  format: json",
             "retry:", f"  attempts: {random.randint(2, 6)}",
             f"  backoff_ms: {random.choice([200, 500, 1000])}"]
    return inicio, resto


def gerar_json(nome):
    env = random.choice(AMBIENTES)
    inicio = ["{", f'  "name": "{nome}",', f'  "version": "{_ver()}",', f'  "env": "{env}",']
    resto = ['  "database": {', f'    "host": "db-{env}.interno",', '    "port": 5432',
             '  },', '  "features": {',
             f'    "cache": {random.choice(["true", "false"])},',
             f'    "metrics": {random.choice(["true", "false"])}', '  }', '}']
    return inicio, resto


def gerar_md(nome):
    inicio = [f"# Notas {nome} {datetime.now():%d/%m}", ""]
    resto = ["## Pendências", ""] + [f"- {t}" for t in random.sample(TAREFAS, 3)] + \
            ["", "## Observações", "", f"- {random.choice(NOMES)} subiu com versão {_ver()}"]
    return inicio, resto


def gerar_txt(nome):
    inicio = [f"TODO {nome} {datetime.now():%d/%m/%Y}", ""]
    resto = [f"[ ] {t}" for t in random.sample(TAREFAS, 4)]
    return inicio, resto


def gerar_extra(ext):
    """Linhas para acrescentar a um arquivo já existente."""
    if ext == "yaml":
        return [f"{random.choice(['cache', 'queue', 'metrics'])}:",
                f"  enabled: {random.choice(['true', 'false'])}",
                f"  ttl: {random.choice([60, 300, 900])}"]
    if ext == "md":
        return ["", f"- {random.choice(TAREFAS)}"]
    if ext == "txt":
        return [f"[ ] {random.choice(TAREFAS)}"]
    return []


GERADORES = {"yaml": gerar_yaml, "json": gerar_json, "md": gerar_md, "txt": gerar_txt}
PADRAO_NOME = re.compile(r"^(" + "|".join(re.escape(n) for n in NOMES) + r")-\d{4}-\d{6}\.(yaml|json|md|txt)$")


def arquivo_do_simulador(p):
    return p.is_file() and bool(PADRAO_NOME.match(p.name))

SETTINGS_VSCODE = {
    "editor.autoClosingBrackets": "never",
    "editor.autoClosingQuotes": "never",
    "editor.autoSurround": "never",
    "editor.autoIndent": "none",
    "editor.formatOnType": False,
    "editor.formatOnSave": False,
    "editor.quickSuggestions": False,
    "editor.suggestOnTriggerCharacters": False,
    "editor.acceptSuggestionOnEnter": "off",
    "editor.wordBasedSuggestions": "off",
    "editor.snippetSuggestions": "none",
    "files.autoSave": "off",
}


# ------------------------------------------------------------------ simulador

class Simulador:
    def __init__(self, cfg):
        self.cfg = cfg
        self.mouse = MouseController()
        self.kb = KbController()
        self.detector = DetectorUsuario()
        self.largura, self.altura = tamanho_tela()
        self.terminais = {}          # tipo -> {"proc": Popen, "hwnd": int}
        self.ultimo_contexto = None
        self._bloqueado_antes = False
        ws = cfg["vscode"].get("pasta_workspace") or str(BASE)
        self.workspace = Path(ws) if Path(ws).is_absolute() else BASE / ws
        self.rascunho = self.workspace / cfg["vscode"]["pasta_rascunho"]
        self.rascunho.mkdir(parents=True, exist_ok=True)
        vs = self.workspace / ".vscode"
        vs.mkdir(exist_ok=True)
        (vs / "settings.json").write_text(json.dumps(SETTINGS_VSCODE, indent=2), encoding="utf-8")
        self.vscode_cmd = self._resolver_vscode()
        random.seed()

    def _resolver_vscode(self):
        cmd = self.cfg["vscode"].get("comando", "code")
        achado = shutil.which(cmd)
        if achado:
            return achado
        candidato = Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / "bin" / "code.cmd"
        return str(candidato) if candidato.exists() else cmd

    # ---- agenda e segurança

    def dentro_do_horario(self):
        h = self.cfg["horario"]
        agora = datetime.now()
        if h.get("dias_uteis_apenas") and agora.weekday() >= 5:
            return False
        t = agora.time()
        if not (parse_hora(h["inicio"]) <= t <= parse_hora(h["fim"])):
            return False
        if parse_hora(h["almoco_inicio"]) <= t < parse_hora(h["almoco_fim"]):
            return False
        return True

    def intensidade_agora(self):
        tabela = self.cfg["ritmo"].get("intensidade_por_hora", {})
        return float(tabela.get(f"{datetime.now().hour:02d}", 0.7))

    def usuario_presente(self):
        s = self.cfg["seguranca"]
        if not s.get("pausar_se_usuario_mexer", True):
            return False
        return self.detector.segundos_desde_usuario() < s["retomar_apos_inativo_seg"]

    def bloqueador_aberto(self):
        """Nome do bloqueador (ex.: chrome.exe) se a janela em foco for dele, senão None."""
        hwnd = janela_ativa()
        exe = exe_da_janela(hwnd)
        titulo = titulo_janela(hwnd).lower() if WIN and hwnd else ""
        for p in self.cfg["seguranca"].get("processos_bloqueadores", []):
            nome = p.lower()
            if exe == nome or nome.replace(".exe", "") in titulo:
                return p
        return None

    def pedido_de_parada(self):
        return (BASE / self.cfg["seguranca"]["arquivo_parada"]).exists()

    def motivo_parada(self):
        if self.pedido_de_parada():
            return "arquivo de parada"
        if not self.dentro_do_horario():
            return "fora do horário"
        b = self.bloqueador_aberto()
        if b:
            return f"{b} em foco"
        if self.usuario_presente():
            return f"atividade sua há {self.detector.segundos_desde_usuario():.0f}s"
        return "?"

    def pode_continuar(self):
        """Checagem rápida usada entre ações."""
        if self.pedido_de_parada() or not self.dentro_do_horario():
            return False
        if self.bloqueador_aberto() or self.usuario_presente():
            return False
        return True

    # ---- digitação com ritmo

    def _dormir(self, a, b):
        time.sleep(random.uniform(a, b))

    def _tecla(self, *teclas):
        for t in teclas:
            self.kb.press(t)
        self._dormir(0.05, 0.12)
        for t in reversed(teclas):
            self.kb.release(t)

    class Abortado(Exception):
        """Usuário assumiu ou a janela mudou no meio de uma ação."""

    def _seguro_para_digitar(self, hwnd):
        if self.detector.segundos_desde_usuario() < 3:
            raise Simulador.Abortado("você mexeu")
        if hwnd and janela_ativa() != hwnd:
            raise Simulador.Abortado(f"janela mudou para '{titulo_ativo()[:40]}'")

    def _digitar(self, texto, enter=False, hwnd=None):
        """Digita com ritmo humano. Aborta no primeiro sinal de que o
        usuário assumiu ou de que a janela em foco não é mais a esperada."""
        d = self.cfg["digitacao"]
        vizinhas = "qwertyuiopasdfghjklzxcvbnm"
        for ch in texto:
            self._seguro_para_digitar(hwnd)
            if ch.isalpha() and random.random() < d["taxa_erro"]:
                self.kb.type(random.choice(vizinhas))
                self._dormir(0.15, 0.4)
                self._seguro_para_digitar(hwnd)
                self._tecla(Key.backspace)
                self._dormir(0.1, 0.25)
            self.kb.type(ch)
            atraso = random.uniform(d["atraso_tecla_min_seg"], d["atraso_tecla_max_seg"])
            if ch in " ,.;:":
                atraso *= random.uniform(1.5, 3.0)
            time.sleep(atraso)
        if enter:
            self._dormir(0.2, 0.6)
            self._seguro_para_digitar(hwnd)
            self._tecla(Key.enter)

    # ---- ações extras

    def mover_mouse(self):
        x0, y0 = self.mouse.position
        margem = 80
        x1 = random.randint(margem, self.largura - margem)
        y1 = random.randint(margem, self.altura - margem)
        cx = (x0 + x1) / 2 + random.uniform(-200, 200)
        cy = (y0 + y1) / 2 + random.uniform(-200, 200)
        passos = random.randint(25, 60)
        dur = random.uniform(0.3, 1.1)
        for i in range(1, passos + 1):
            if self.detector.segundos_desde_usuario() < 3:
                raise Simulador.Abortado("você mexeu")
            t = i / passos
            t = t * t * (3 - 2 * t)
            x = (1 - t) ** 2 * x0 + 2 * (1 - t) * t * cx + t ** 2 * x1
            y = (1 - t) ** 2 * y0 + 2 * (1 - t) * t * cy + t ** 2 * y1
            self.mouse.position = (int(x), int(y))
            time.sleep(dur / passos)
        log(f"mouse -> ({x1}, {y1})")

    def scroll(self):
        n = random.randint(2, 8)
        sentido = random.choice([-1, -1, 1])
        for _ in range(n):
            if self.detector.segundos_desde_usuario() < 3:
                raise Simulador.Abortado("você mexeu")
            self.mouse.scroll(0, sentido)
            self._dormir(0.05, 0.2)
        log(f"scroll {'baixo' if sentido < 0 else 'cima'} x{n}")

    # ---- terminais (PowerShell e WSL)

    def _garantir_terminal(self, tipo):
        t = self.terminais.get(tipo)
        if t and t["proc"].poll() is None and janela_existe(t["hwnd"]):
            return t["hwnd"]
        if tipo == "powershell":
            cmd = ["conhost.exe", "powershell.exe", "-NoExit", "-NoLogo", "-Command",
                   f"$host.UI.RawUI.WindowTitle='PowerShell'; Set-Location '{self.rascunho}'"]
        else:
            cmd = ["conhost.exe", "wsl.exe"]
        exe_esperado = "powershell.exe" if tipo == "powershell" else "wsl.exe"
        antes = {h for h, _, _ in listar_janelas()}
        try:
            proc = subprocess.Popen(cmd)
        except Exception as e:
            log(f"não consegui abrir {tipo}: {e}")
            return None
        # a janela do console pertence ao processo cliente (powershell/wsl),
        # não ao conhost: procuramos uma janela nova do executável esperado
        hwnd = None
        for _ in range(60):
            time.sleep(0.25)
            novas = [h for h, _, _ in listar_janelas()
                     if h not in antes and exe_da_janela(h) == exe_esperado]
            if novas:
                hwnd = novas[0]
                break
        if not hwnd:
            log(f"janela do {tipo} não apareceu")
            return None
        time.sleep(3 if tipo == "wsl" else 1.5)  # espera o prompt ficar pronto
        self.terminais[tipo] = {"proc": proc, "hwnd": hwnd}
        log(f"abri janela do {tipo}")
        return hwnd

    def fechar_terminal(self, tipo, motivo="encerrando"):
        t = self.terminais.pop(tipo, None)
        if not t:
            return
        try:
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(t["proc"].pid)],
                           capture_output=True, creationflags=CREATE_NO_WINDOW, timeout=10)
        except Exception:
            pass
        if janela_existe(t["hwnd"]):
            WM_CLOSE = 0x0010
            user32.PostMessageW(t["hwnd"], WM_CLOSE, 0, 0)
        log(f"fechei janela do {tipo} ({motivo})")

    def fechar_terminais(self, motivo="encerrando"):
        for tipo in list(self.terminais):
            self.fechar_terminal(tipo, motivo)

    def acao_terminal(self, tipo):
        hwnd = self._garantir_terminal(tipo)
        if not hwnd:
            return
        if not focar(hwnd, self.kb) or janela_ativa() != hwnd:
            log(f"{tipo}: não consegui focar a janela, pulando")
            return
        chave = "comandos_powershell" if tipo == "powershell" else "comandos_wsl"
        cmd = random.choice(self.cfg["terminal"][chave])
        self._dormir(0.5, 1.5)
        self._seguro_para_digitar(hwnd)
        self._digitar(cmd, enter=True, hwnd=hwnd)
        log(f"{tipo}: {cmd}")
        self._dormir(1.0, 3.0)

    # ---- VS Code

    def _abrir_vscode(self, alvo):
        try:
            subprocess.Popen(["cmd.exe", "/c", self.vscode_cmd, "-r", str(alvo)],
                             creationflags=CREATE_NO_WINDOW)
            return True
        except Exception as e:
            log(f"não consegui chamar o VS Code: {e}")
            return False

    def _garantir_vscode(self):
        hwnd = janela_por_titulo("Visual Studio Code")
        if hwnd:
            return hwnd
        if not self._abrir_vscode(self.workspace):
            return None
        for _ in range(80):
            time.sleep(0.25)
            hwnd = janela_por_titulo("Visual Studio Code")
            if hwnd:
                log("abri o VS Code")
                time.sleep(3)
                return hwnd
        log("VS Code não abriu")
        return None

    def _limpar_rascunho(self):
        arquivos = sorted((p for p in self.rascunho.iterdir() if arquivo_do_simulador(p)),
                          key=lambda p: p.stat().st_mtime)
        excedente = len(arquivos) - self.cfg["vscode"]["max_arquivos"]
        for p in arquivos[:max(0, excedente)]:
            p.unlink(missing_ok=True)

    def _escolher_arquivo(self):
        """Retorna (caminho, linhas_a_digitar, novo)."""
        v = self.cfg["vscode"]
        existentes = [p for p in self.rascunho.iterdir()
                      if arquivo_do_simulador(p) and p.suffix[1:] in ("yaml", "md", "txt")]
        if existentes and random.random() < v["chance_editar_existente"]:
            p = random.choice(existentes)
            return p, gerar_extra(p.suffix[1:]), False
        ext = random.choice(v["extensoes"])
        servico = random.choice(NOMES)
        inicio, resto = GERADORES[ext](servico)
        p = self.rascunho / f"{servico}-{datetime.now():%d%m-%H%M%S}.{ext}"
        p.write_text("\n".join(inicio) + "\n", encoding="utf-8")
        return p, resto, True

    def acao_vscode(self):
        if not self._garantir_vscode():
            return
        self._limpar_rascunho()
        arquivo, linhas, novo = self._escolher_arquivo()
        if not self._abrir_vscode(arquivo):
            return
        self._dormir(2.0, 4.0)
        hwnd = janela_por_titulo(arquivo.name, "Visual Studio Code")
        if not hwnd or not focar(hwnd, self.kb):
            log("vscode: janela do arquivo não ficou ativa, pulando")
            return
        if arquivo.name not in titulo_ativo():
            log(f"vscode: janela ativa é '{titulo_ativo()}', pulando")
            return
        self._seguro_para_digitar(hwnd)
        self._tecla(Key.ctrl, Key.end)
        self._dormir(0.3, 0.8)
        if not novo:
            self._seguro_para_digitar(hwnd)
            self._tecla(Key.enter)
        for linha in linhas:
            if not self.pode_continuar():
                log("vscode: interrompido no meio da edição")
                return
            self._digitar(linha, enter=True, hwnd=hwnd)
            self._dormir(0.3, 2.0)
        if random.random() < 0.8:
            self._dormir(0.5, 1.5)
            self._seguro_para_digitar(hwnd)
            self._tecla(Key.ctrl, "s")
            salvou = " (salvo)"
        else:
            salvou = ""
        log(f"vscode: {'criou' if novo else 'editou'} {arquivo.name}, {len(linhas)} linhas{salvou}")

    # ---- orquestração

    def escolher_contexto(self):
        pesos = {k: v for k, v in self.cfg["contextos"].items() if v > 0}
        if not pesos:
            return None
        if len(pesos) > 1 and self.ultimo_contexto in pesos:
            pesos = {k: v for k, v in pesos.items() if k != self.ultimo_contexto}
        ctx = random.choices(list(pesos), weights=list(pesos.values()))[0]
        self.ultimo_contexto = ctx
        return ctx

    def rajada(self, ctx):
        r = self.cfg["ritmo"]
        extras = self.cfg["acoes_extras"]
        principal = (lambda: self.acao_vscode()) if ctx == "vscode" else (lambda: self.acao_terminal(ctx))
        acoes = [principal] * 5
        if extras.get("mover_mouse"):
            acoes += [self.mover_mouse] * 3
        if extras.get("scroll"):
            acoes += [self.scroll] * 1
        fim = time.time() + random.uniform(r["rajada_min_seg"], r["rajada_max_seg"])
        log(f"início da rajada em {ctx}")
        while time.time() < fim:
            if not self.pode_continuar():
                log(f"rajada interrompida ({self.motivo_parada()})")
                return
            try:
                random.choice(acoes)()
            except Simulador.Abortado as e:
                log(f"ação abortada na hora: {e}")
                return
            base = random.uniform(r["intervalo_acao_min_seg"], r["intervalo_acao_max_seg"])
            time.sleep(base / max(self.intensidade_agora(), 0.2))
        log("fim da rajada")
        if ctx in self.terminais and random.random() < self.cfg["terminal"].get("chance_fechar_ao_fim", 0.3):
            self.fechar_terminal(ctx, "fim da rajada")

    def executar(self):
        s = self.cfg["seguranca"]
        r = self.cfg["ritmo"]
        log(f"iniciado ({self.largura}x{self.altura}). Ctrl+C ou {s['arquivo_parada']} para parar.")
        log(f"VS Code: {self.vscode_cmd} | workspace: {self.workspace} | rascunho: {self.rascunho}")
        acordada = False
        ultimo_aviso = 0.0
        fora_antes = False
        try:
            while True:
                if self.pedido_de_parada():
                    log("arquivo de parada encontrado, encerrando")
                    (BASE / s["arquivo_parada"]).unlink(missing_ok=True)
                    break
                if not self.dentro_do_horario():
                    if acordada:
                        manter_tela_acordada(False); acordada = False
                    if not fora_antes:
                        self.fechar_terminais("fora do horário")
                        log("fora do horário, aguardando")
                        fora_antes = True
                    time.sleep(60)
                    continue
                if fora_antes:
                    log("de volta ao horário")
                    fora_antes = False
                bloq = self.bloqueador_aberto()
                if bloq:
                    if s.get("encerrar_ao_detectar_bloqueador"):
                        log(f"{bloq} em foco, encerrando")
                        break
                    if not self._bloqueado_antes:
                        log(f"{bloq} em foco, pausado até sair dele")
                        self._bloqueado_antes = True
                    time.sleep(10)
                    continue
                if self._bloqueado_antes:
                    log("bloqueador saiu do foco, retomando quando ficar inativo")
                    self._bloqueado_antes = False
                if s.get("manter_tela_acordada") and not acordada:
                    manter_tela_acordada(True); acordada = True
                if self.usuario_presente():
                    if time.time() - ultimo_aviso > 30:
                        falta = s["retomar_apos_inativo_seg"] - self.detector.segundos_desde_usuario()
                        log(f"você está ativo, começo após {falta:.0f}s sem atividade")
                        ultimo_aviso = time.time()
                    time.sleep(5)
                    continue
                ctx = self.escolher_contexto()
                if not ctx:
                    log("nenhum contexto habilitado em config.json")
                    break
                self.rajada(ctx)
                pausa = random.uniform(r["pausa_min_seg"], r["pausa_max_seg"])
                log(f"pausa de {pausa:.0f}s")
                time.sleep(pausa)
        except KeyboardInterrupt:
            log("encerrado pelo usuário")
        finally:
            self.fechar_terminais()
            manter_tela_acordada(False)


def main():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    caminho = sys.argv[1] if len(sys.argv) > 1 else str(BASE / "config.json")
    with open(caminho, encoding="utf-8") as f:
        cfg = json.load(f)
    Simulador(cfg).executar()


if __name__ == "__main__":
    main()
