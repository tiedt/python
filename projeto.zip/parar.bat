@echo off
echo parar > "%~dp0PARAR.txt"
echo Pedido de parada enviado.
