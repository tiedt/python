# Projeto

Gera atividade com ritmo humano alternando entre VS Code, PowerShell e WSL,
só dentro do horário configurado. Pausa sozinho quando você usa a máquina ou
deixa o Chrome em primeiro plano.

## Instalação (no Windows, não no WSL)

    pip install pynput

O comando `code` precisa estar no PATH (padrão da instalação do VS Code).

## Uso

    cd C:\Users\lussandro.ilha\projeto
    python projeto.py

Para parar: Ctrl+C no terminal, ou crie um arquivo `PARAR.txt` nesta pasta.

## O que ele faz

- Abre o VS Code na pasta configurada em `pasta_workspace` (Documentos) e grava tudo na subpasta `rascunho`. Ele só apaga ou reedita arquivos que ele mesmo criou, nunca os seus. Cria e cria arquivos yaml, json, md e txt com
  conteúdo plausível, digitando parte deles e salvando. Às vezes reedita um
  arquivo existente. A pasta tem settings que desligam autocompletar e
  fechamento automático de aspas para a digitação sair limpa.
- Abre uma janela de PowerShell e uma de WSL e digita comandos inofensivos
  de listagem e consulta.
- Alterna entre esses três contextos em rajadas, com mouse e scroll no meio.
- Só digita se a janela certa estiver em primeiro plano. Se não estiver, pula.

## Segurança

- Qualquer mouse ou tecla sua pausa tudo, e ele só volta após 2 minutos parado.
- Se a janela em primeiro plano for do Chrome, ele fica pausado até você sair dela. O Chrome pode ficar aberto atrás.
  Para encerrar de vez em vez de pausar, use `encerrar_ao_detectar_bloqueador`.
- A lista `processos_bloqueadores` aceita outros executáveis.

## Primeira vez

Abra a pasta de workspace no VS Code uma vez manualmente e aceite o aviso de
confiança da pasta, senão o diálogo pode atrapalhar a primeira digitação.
